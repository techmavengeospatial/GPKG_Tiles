GEOPACKAGE_STYLESHEETS_EXTENSION_NAME = "styles"
STYLESHEETS_TILES_DEFINITION = "https://portal.opengeospatial.org/files/?artifact_id=82762"
GEOPACKAGE_SYMBOLS_TABLE_NAME = "gpkgext_symbols"
GEOPACKAGE_STYLESHEETS_TABLE_NAME = "gpkgext_stylesheets" # type: str